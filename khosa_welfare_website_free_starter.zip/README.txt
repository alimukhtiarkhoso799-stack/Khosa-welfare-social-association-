کھوسہ ویلفیئر سوشل ایسوسی ایشن پاکستان — ویب سائٹ فائلیں

فائل:
- index.html : موبائل فرینڈلی اردو ویب سائٹ

استعمال:
1. index.html کو براؤزر میں کھول کر دیکھیں۔
2. شائع کرنے سے پہلے فون، ای میل، پتہ، اصل لوگو، رجسٹریشن کی معلومات اور سوشل میڈیا لنکس تبدیل کریں۔
3. مفت ہوسٹنگ کے لیے GitHub اکاؤنٹ بنائیں، نیا public repository بنائیں، index.html اپ لوڈ کریں۔
4. Repository Settings > Pages میں جا کر publishing source کو منتخب کریں۔ GitHub Pages کے سرکاری طریقۂ کار کی پیروی کریں:
https://docs.github.com/en/pages/getting-started-with-github-pages

نوٹ:
یہ static website ہے۔ اس میں ابھی database، admin dashboard، آن لائن donation processing یا volunteer form submissions شامل نہیں۔ عطیات وصول کرنے کے لیے تصدیق شدہ ادائیگی کا طریقہ الگ سے ترتیب دینا ہوگا۔
